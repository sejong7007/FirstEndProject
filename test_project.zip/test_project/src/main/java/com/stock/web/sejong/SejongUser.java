package com.stock.web.sejong;

public class SejongUser {

	
	
}
